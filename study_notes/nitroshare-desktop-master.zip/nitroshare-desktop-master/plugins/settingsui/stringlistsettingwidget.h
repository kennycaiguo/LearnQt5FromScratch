/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2018 Nathan Osman
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#ifndef STRINGLISTSETTINGWIDGET_H
#define STRINGLISTSETTINGWIDGET_H

#include <QListWidget>
#include <QPushButton>

#include "settingwidget.h"

class Setting;

class StringListSettingWidget : public SettingWidget
{
    Q_OBJECT

public:

    explicit StringListSettingWidget(Setting *setting);

    virtual QVariant value() const;
    virtual void setValue(const QVariant &value);

private slots:

    void onAddClicked();
    void onRemoveClicked();
    void onItemSelectionChanged();

private:

    QListWidget *mListWidget;
    QPushButton *mRemoveButton;
};

#endif // STRINGLISTSETTINGWIDGET_H
